package Ex3;

import java.awt.image.BufferedImage;

public class HouseToLet extends ToLet{
	
	public HouseToLet(int bedrooms, String description, BufferedImage img, double rent) {
		super(bedrooms, description, img, rent);
	}

	
}	
