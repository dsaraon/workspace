package Ex3;

import java.awt.image.BufferedImage;

public class ApartmentForSale extends ForSale{

	public ApartmentForSale(int bedrooms, String description, BufferedImage img, double price) {
		super(bedrooms, description, img, price);
	}
	
}
