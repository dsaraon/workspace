package Ex3;

import java.awt.image.BufferedImage;

public class ApartmentToLet extends ToLet{
	
	public ApartmentToLet(int bedrooms, String description, BufferedImage img, double rent) {
		super(bedrooms, description, img, rent);
	
	}
	
}
