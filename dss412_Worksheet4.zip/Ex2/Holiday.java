package Ex2;
public interface Holiday {
   int getDaysOfHolidays();
}