
public class Ex4 {
			
	public static void quickSort(String[] arr){
		
		
		//helper method to find pivot and perform sorting 
		qSort(arr, 0, arr.length-1); // pass the first and last index of the array 
		
		
	}
	public static void qSort(String[] arr, int start, int last){
		int i = start;
		int j = last; 
		int pivotIndex = (start + last) / 2;
		String pivot = arr[pivotIndex]; 
		
		while(true){
			while(arr[i].length() < pivot.length() ){
				i++;
			}
			while(arr[j].length() > pivot.length() ){
				j--;
			}
			
			if( arr[i].length() < arr[j].length() ){
				String temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp; 
			}
			else{
				return ;
			}
		}
		
		if(start < pivotIndex){
			qSort(arr, start, pivotIndex);
		}
		if(last > pivotIndex+1){
			qSort(arr, pivotIndex+1, last);
		}
	}
	
	public static void main(String[] args){
		String arr[] = {"wtiting", "code", "i", "am", ",", "quick", "sort", "be", "the", "one"}; 
		quickSort(arr);
		for(int i = 0; i <arr.length; i++){
			System.out.println(arr[i] + " ");
		}
	}
	
	
}
