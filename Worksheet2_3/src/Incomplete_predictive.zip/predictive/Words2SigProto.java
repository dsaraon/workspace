package predictive;

public class Words2SigProto {
	
	public static void main(String[] args){
		
		for (String s: args){
			String s2 =  PredictivePrototype.wordsToSignature(s);
			System.out.println(s + " : "  + s2);
		}
	}
}
