package predictive;

import static org.junit.Assert.*;

import org.junit.Test;

public class PredictivePrototypeTest {

	@Test
	public void wordsToSignatureTest1() {
		String result = PredictivePrototype.wordsToSignature("home");
		String expected = "4663";
		
		assertTrue(expected.equals(result));
	}
	
	@Test
	public void wordsToSignatureTest2() {
		String result = PredictivePrototype.wordsToSignature("Mumbai2Delhi");
		String expected = "686224 33544";
		
		assertTrue(expected.equals(result));
	}
	
	@Test
	public void wordsToSignatureTest3() {
		boolean x = PredictivePrototype.isValidWord("Mumbai2Delhi");
		
		assertFalse(x);
	}
	
	
	
}
