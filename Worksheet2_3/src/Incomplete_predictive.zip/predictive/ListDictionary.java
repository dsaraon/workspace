package predictive;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ListDictionary {
	
	ArrayList<WordSig> list = new ArrayList<WordSig>();
	
	public ListDictionary(){
		try{
			File dict = new File("/usr/share/dict/words");
			
			Scanner s = new  Scanner(dict);
			while(s.hasNextLine()){
				String word = s.nextLine().toLowerCase();
				WordSig ws = new WordSig(word, PredictivePrototype.wordsToSignature(word));
				list.add(ws);
			}
			s.close();
		}
		catch(FileNotFoundException e){
			System.out.println("not found");
			e.printStackTrace();
		}
	}
	
	
}
